from flask import Flask, request, redirect, url_for, flash, render_template_string, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_mail import Mail, Message
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'rony807777@gmail.com'  # Enter your email
app.config['MAIL_PASSWORD'] = 'Rony807777@gmail'          # Enter your password
app.config['MAIL_DEFAULT_SENDER'] = 'amatak.io@outlook.com'  # Enter your email
mail = Mail(app)

app.config['USER_DATA'] = {}  # In-memory store for user data (for demo purposes)

ALLOWED_EXTENSIONS = {'txt', 'py', 'html', 'css', 'js', 'md', 'xlsm', 'pdf'}

def send_email(subject, recipient, body):
    msg = Message(subject, recipients=[recipient])
    msg.body = body
    mail.send(msg)

@app.route('/')
def index():
    return render_template_string('''
    <!doctype html>
    <title>User Management System</title>
    <h1>User Management System</h1>
    <h2>Create Account</h2>
    <form action="{{ url_for('signup') }}" method="post">
        <label for="username">Username:</label><br>
        <input type="text" name="username" required><br>
        <label for="password">Password:</label><br>
        <input type="password" name="password" required><br>
        <input type="submit" value="Sign Up">
    </form>

    <h2>Log In</h2>
    <form action="{{ url_for('login') }}" method="post">
        <label for="username">Username:</label><br>
        <input type="text" name="username" required><br>
        <label for="password">Password:</label><br>
        <input type="password" name="password" required><br>
        <input type="submit" value="Log In">
    </form>
    ''')

@app.route('/signup', methods=['POST'])
def signup():
    username = request.form['username']
    password = request.form['password']

    if username in app.config['USER_DATA']:
        flash('User already exists.')
    else:
        hashed_password = generate_password_hash(password)
        app.config['USER_DATA'][username] = hashed_password
        flash('User successfully created. Please verify your email.')

        # Send verification email
        send_email(
            subject='Account Verification',
            recipient=username,  # In a real app, this should be email, not username
            body='Thank you for signing up! Please verify your account.'
        )

    return redirect(url_for('index'))

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    if username in app.config['USER_DATA'] and check_password_hash(app.config['USER_DATA'][username], password):
        session['username'] = username
        flash('Login successful.')
        return redirect(url_for('index'))
    else:
        flash('Invalid username or password.')

    return redirect(url_for('index'))

@app.route('/reset_password', methods=['POST'])
def reset_password():
    username = request.form['username']
    
    if username in app.config['USER_DATA']:
        # Here you would implement password reset logic
        # For simplicity, we just send an alert about password reset
        send_email(
            subject='Password Reset Request',
            recipient=username,  # In a real app, this should be email
            body='You have requested to reset your password. Follow the instructions to reset your password.'
        )
        flash('Password reset email sent.')
    else:
        flash('Username not found.')

    return redirect(url_for('index'))

@app.route('/update_password', methods=['POST'])
def update_password():
    username = session.get('username')
    if not username:
        flash('You must be logged in to update your password.')
        return redirect(url_for('login'))
    
    new_password = request.form['new_password']
    app.config['USER_DATA'][username] = generate_password_hash(new_password)
    flash('Password updated successfully.')

    # Send confirmation email
    send_email(
        subject='Password Updated',
        recipient=username,  # In a real app, this should be email
        body='Your password has been updated successfully.'
    )
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
